#include<iostream>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
using namespace std;

int main()
{
	int i,status,N;
	pid_t pid;


	pid = fork();
	
	if(pid ==0)
	{
		for(i=1;1<N;i++)
			if(i%2 ==0)
			{
			cout<<"The numbers are even %d\n"<<i<<endl;
			cout<<"parent process for even num"<<endl;
			}
	}
	else
	{
		if(pid>0)
		pid = waitpid(pid,&status,0);
			for(i=1;i<N;i++)
				if(i%2 != 0)
				{
				cout<<"The numbers are odd %d\n"<<i<<endl;
				}
	}
	return 0;
}

